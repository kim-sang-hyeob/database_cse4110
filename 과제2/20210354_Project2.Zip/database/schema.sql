CREATE DATABASE IF NOT EXISTS store;
USE store;

DROP TABLE IF EXISTS sale_detail;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS sale;
DROP TABLE IF EXISTS customer;
DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS vendor;
DROP TABLE IF EXISTS store;

CREATE DATABASE IF NOT EXISTS store;
USE store;


CREATE TABLE store (
    store_id     INT ,
    store_name   VARCHAR(100)  NOT NULL UNIQUE,
    address      VARCHAR(100) NOT NULL,
    open_time    TIME NOT NULL,
    close_time   TIME  NOT NULL,
    owner_type   VARCHAR(20)  NOT NULL ,
    PRIMARY KEY(store_id)
);

CREATE TABLE vendor (
    vendor_id    INT ,
    vendor_name  VARCHAR(60)  NOT NULL,
    contact_info VARCHAR(100) ,
    PRIMARY KEY(vendor_id)
);


CREATE TABLE product (
    product_upc  VARCHAR(25) ,
    vendor_id    INT ,
    product_name VARCHAR(100) NOT NULL,
    brand        VARCHAR(100) NOT NULL,
    price        DECIMAL(8,2) CHECK(price > 0),
    size         VARCHAR(50),
    PRIMARY KEY (product_upc) ,
    FOREIGN KEY (vendor_id) REFERENCES vendor(vendor_id) ON DELETE SET NULL
);


CREATE TABLE customer (
    customer_id  INT, 
    name         VARCHAR(100)  NOT NULL ,
    phone        VARCHAR(20) UNIQUE,
    email        VARCHAR(60) UNIQUE,
    point        INT DEFAULT 0 ,
    PRIMARY KEY (customer_id)
);


CREATE TABLE sale (
    sale_id     INT,                           
    customer_id INT,
    store_id    INT ,
    pay_type    VARCHAR(10)  NOT NULL,           
    total_money DECIMAL(10,2),
    sale_time   DATETIME     NOT NULL,
    PRIMARY KEY (sale_id),
    FOREIGN KEY (customer_id) REFERENCES customer (customer_id) ON DELETE SET NULL,
    FOREIGN KEY (store_id)    REFERENCES store (store_id) ON DELETE SET NULL
);


CREATE TABLE inventory (
    store_id      INT,
    product_upc   VARCHAR(25),
    current_quantity INT,
    reorder_thresholds INT ,
    recent_order_history DATE , 
    PRIMARY KEY (store_id, product_upc),
    FOREIGN KEY (store_id)    REFERENCES store   (store_id) ON DELETE CASCADE,
    FOREIGN KEY (product_upc) REFERENCES product (product_upc)  ON DELETE CASCADE
);

CREATE TABLE sale_detail (
    sale_id     INT,
    product_upc VARCHAR(25),
    quantity  INT NOT NULL,
    PRIMARY KEY (sale_id, product_upc),
    FOREIGN KEY (sale_id) REFERENCES sale (sale_id)  ON DELETE CASCADE,
    FOREIGN KEY (product_upc) REFERENCES product (product_upc)   ON DELETE CASCADE
);
