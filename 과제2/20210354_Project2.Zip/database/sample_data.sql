/* ───────────────────────────────────────────────
   Demo data for Project-2 convenience-store schema
   모든 SELECT TYPE(1-7) 결과가 하나 이상 나오도록 설계
   ─────────────────────────────────────────────── */

/* 1. Store ─ Franchise 2곳 + Corporate 1곳 */
INSERT INTO store (store_id, store_name, address,
                   open_time, close_time, owner_type)
VALUES
 (1, 'Hongdae Franchise',  'Seoul Mapo-gu',  '08:00:00','23:00:00','Franchise'),
 (2, 'Gangnam Central',    'Seoul Gangnam-gu','07:00:00','24:00:00','Corporate'),
 (3, 'Busan Harbor',       'Busan Jung-gu',  '09:00:00','22:00:00','Franchise');



/* 2. Vendor */
INSERT INTO vendor (vendor_id, vendor_name, contact_info) VALUES
 (101, 'CafeRoasters', '02-123-4567'),
 (102, 'SnackWorld',   '02-987-6543');

/* 3. Product -- 5종 (Vendor 101이 3종 → TYPE 4에서 1등) */
INSERT INTO product
(product_upc, vendor_id, product_name, brand, price, size) VALUES
 ('1000001',101,'coffee','CafeRoasters',10.00,'200 g'),
 ('1000002',101,'latte','CafeRoasters',4.00,'250 ml'),
 ('1000003',102,'choco Bar','SnackWorld',1.50,'45 g'),
 ('1000004',102,'potato Chips','SnackWorld',2.00,'90 g'),
 ('1000005',101,'espresso','CafeRoasters',3.50,'30 ml');

/* 4. Customer (2명) */
INSERT INTO customer
(customer_id,name,phone,email,point) VALUES
 (201,'Kim Minji','010-1111-2222','minji@example.com',0),
 (202,'Lee Jinsu','010-3333-4444','jinsu@example.com',0);

/* 5. Inventory  ─ 재고·재주문 임계치(★TYPE 1,5,7) */
INSERT INTO inventory
(store_id, product_upc, current_quantity, reorder_thresholds, recent_order_history) VALUES
 -- Store-1 (가맹점, 품목 5개 → variety 최고)
 (1,'1000001',  5,10,'2025-05-10'),  -- ↓ 재주문 대상
 (1,'1000002', 50,20,'2025-05-10'),
 (1,'1000003', 30,20,'2025-05-10'),
 (1,'1000004',  5,10,'2025-05-10'),  -- ↓ 재주문 대상
 (1,'1000005', 20,10,'2025-05-10'),

 -- Store-2 (직영점)
 (2,'1000001', 20,10,'2025-05-12'),
 (2,'1000003',  5,10,'2025-05-12'),  -- ↓ 재주문 대상
 (2,'1000005', 30,15,'2025-05-12'),

 -- Store-3 (가맹점)
 (3,'1000001', 15,10,'2025-05-12'),
 (3,'1000002', 10,20,'2025-05-12'),  -- ↓ 재주문 대상
 (3,'1000004', 25,10,'2025-05-12'),
 (3,'1000005',  5,10,'2025-05-12');  -- ↓ 재주문 대상

/* 6. Sale  ─ 전부 2025년 2분기(Q2)·그중 1001/1002/1005는 “지난달(5월)” */
/*          total_money는 대략 계산한 값이니 마음껏 조정 가능 */
INSERT INTO sale
(sale_id, customer_id, store_id, pay_type, total_money, sale_time) VALUES
 (1001,201,1,'Card', 25.00,'2025-05-15 10:00:00'),
 (1002,202,2,'Cash', 18.50,'2025-05-20 14:20:00'),
 (1003,201,1,'Card', 30.00,'2025-04-10 09:00:00'),
 (1004,202,3,'Card', 15.00,'2025-06-05 19:30:00'),
 (1005,201,1,'Cash', 22.50,'2025-05-25 12:00:00');

/* 7. Sale_Detail  ─ 각 영수증별 상품·수량 (★TYPE 2,3,4,6) */
INSERT INTO sale_detail (sale_id, product_upc, quantity) VALUES
 (1001,'1000001',2),  -- Coffee Beans
 (1001,'1000003',3),  -- Choco Bar  ← Coffee와 함께 구매
 (1002,'1000002',2),  -- Latte
 (1002,'1000004',1),  -- Potato Chips
 (1002,'1000003',4),  -- Choco Bar
 (1003,'1000005',3),  -- Espresso
 (1003,'1000003',6),  -- Choco Bar
 (1004,'1000001',1),  -- Coffee Beans
 (1004,'1000002',1),  -- Latte
 (1004,'1000004',2),  -- Potato Chips
 (1005,'1000002',4),  -- Latte
 (1005,'1000003',2);  -- Choco Bar

/* ───────────────────────────────────────────────
   추가 Demo 데이터 (v2)  ─ 2025-Q2 기준
   ─────────────────────────────────────────────── */

/* 1. Store  ─ 새 점포 2곳 */
INSERT INTO store (store_id, store_name, address,
                   open_time, close_time, owner_type) VALUES
 (4, 'Daegu Downtown',  'Daegu Jung-gu',  '06:00:00','22:00:00','Corporate'),
 (5, 'Incheon Airport', 'Incheon Jung-gu','00:00:00','24:00:00','Franchise');

/* 2. Vendor  ─ 음료/건강 간식 전문 공급업체 */
INSERT INTO vendor (vendor_id, vendor_name, contact_info) VALUES
 (103, 'FreshDrinks',   '051-222-3333'),
 (104, 'HealthSnacks',  '052-444-5555');

/* 3. Product  ─ 5종 추가 (Vendor 103·104 주력) */
INSERT INTO product
(product_upc, vendor_id, product_name, brand, price, size) VALUES
 ('1000006',103,'green tea',       'FreshDrinks', 2.50,'300 ml'),
 ('1000007',103,'orange juice',    'FreshDrinks', 3.00,'350 ml'),
 ('1000008',104,'protein bar',     'HealthSnacks',2.20,'50 g'),
 ('1000009',104,'granola cup',     'HealthSnacks',4.00,'200 g'),
 ('1000010',102,'nacho chips',     'SnackWorld',  2.50,'100 g');  -- 기존 Vendor 재활용

/* 4. Customer  ─ 포인트(충성도) 고객 포함 */
INSERT INTO customer
(customer_id,name,phone,email,point) VALUES
 (203,'Park Soyeon','010-5555-6666','soyeon@example.com', 50),
 (204,'Choi Hyunwoo','010-7777-8888','hyunwoo@example.com',120);

/* 5. Inventory  ─ 새 점포 + 기존 점포 품목 확장 & 재주문 임계치 */
/*    ↓ current_quantity < reorder_thresholds 인 행은 TYPE 5 대상 */
INSERT INTO inventory
(store_id, product_upc, current_quantity, reorder_thresholds, recent_order_history) VALUES
 -- Store-4 (Corporate)
 (4,'1000001',25,10,'2025-05-15'),
 (4,'1000006', 5,10,'2025-05-20'),  -- 재주문 필요
 (4,'1000007',40,20,'2025-05-20'),
 (4,'1000008',15,10,'2025-05-20'),

 -- Store-5 (Franchise)
 (5,'1000001',10,10,'2025-05-18'),  -- 임계치 도달
 (5,'1000003',50,20,'2025-05-18'),
 (5,'1000006',20,10,'2025-05-18'),
 (5,'1000009', 8,15,'2025-05-18'),  -- 재주문 필요
 (5,'1000010',25,10,'2025-05-18'),

 -- 기존 Store-2,3에도 신상품 입고
 (2,'1000007',10,20,'2025-05-12'),  -- 아직 넉넉
 (2,'1000008', 5,10,'2025-05-18'),  -- 재주문 필요
 (3,'1000009',12,15,'2025-05-18');  -- 임계치 근접

/* 6. Sale  ─ 모든 점포가 최근 30 일 내 영업 기록 보유 */
/*          → TYPE 2,3 용도 (2025-04~06: 2분기 매출) */
INSERT INTO sale
(sale_id, customer_id, store_id, pay_type, total_money, sale_time) VALUES
 (1006,203,4,'Card',28.00,'2025-05-28 11:15:00'),
 (1007,204,5,'Cash',35.00,'2025-05-30 13:45:00'),
 (1008,202,2,'Card',16.00,'2025-06-08 18:10:00'),
 (1009,203,3,'Card',12.50,'2025-04-22 08:30:00'),
 (1010,201,4,'Cash',20.00,'2025-06-10 09:00:00'),
 (1011,204,5,'Card',40.00,'2025-04-12 17:40:00'),
 (1012,202,2,'Cash',25.00,'2025-05-05 12:30:00');

/* 7. Sale_Detail  ─ 커피 + 동반 구매(Protein Bar 등) 패턴 포함 */
INSERT INTO sale_detail (sale_id, product_upc, quantity) VALUES
 -- #1006 (Store-4)
 (1006,'1000001',1),  -- Coffee Beans
 (1006,'1000006',3),  -- Green Tea
 (1006,'1000008',2),  -- Protein Bar
 -- #1007 (Store-5)
 (1007,'1000002',2),  -- Latte
 (1007,'1000009',3),  -- Granola Cup
 (1007,'1000004',2),  -- Potato Chips
 (1007,'1000001',1),  -- Coffee Beans (커피 연계 구매)
 -- #1008 (Store-2)
 (1008,'1000007',2),  -- Orange Juice
 (1008,'1000003',2),  -- Choco Bar
 -- #1009 (Store-3)
 (1009,'1000001',1),
 (1009,'1000003',3),
 -- #1010 (Store-4)
 (1010,'1000005',2),  -- Espresso
 (1010,'1000008',1),  -- Protein Bar
 -- #1011 (Store-5)
 (1011,'1000010',4),  -- Nacho Chips
 (1011,'1000006',2),  -- Green Tea
 (1011,'1000001',1),  -- Coffee Beans
 -- #1012 (Store-2)
 (1012,'1000003',5),  -- Choco Bar
 (1012,'1000010',2);  -- Nacho Chips

COMMIT;
