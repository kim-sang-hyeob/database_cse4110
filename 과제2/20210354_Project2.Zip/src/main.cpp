#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <mysql.h>

using namespace std;

const char *host = "127.0.0.1";
const char *user = "root";
const char *pw = "1234";
const char *db = "store";
const unsigned int port = 3306;

MYSQL *connection = NULL;
MYSQL conn;
MYSQL_RES *sql_result;
MYSQL_ROW sql_row;

void query_print(const char *query);
void exeproduct();
void exetopselling();
void exestoreperformanc();
void exevendorstats();
void exeinventory();
void exeperchaseing();
void execomparison();

int main(void)
{
    // MySQL 초기화
    MYSQL *conn = mysql_init(nullptr);
    if (!conn)
    {
        std::cerr << "mysql_init() failed\n";
        return 1;
    }

    mysql_ssl_mode sslmode = SSL_MODE_DISABLED;
    mysql_options(conn, MYSQL_OPT_SSL_MODE, &sslmode);

    /* 올바른 호출 ─ MYSQL* 를 그대로 전달 */
    connection = mysql_real_connect(conn, host, user, pw, db, port, NULL, 0);
    if (!connection)
    {
        std::cerr << "DB Connection Error: " << mysql_error(conn) << '\n';
        return 1;
    }

    cout << "Connection Succeed" << endl;

    // 메인 쿼리 선택 루프
    while (true)
    {

        cout << "\n----------- SELECT QUERY TYPES -----------\n";
        cout << "   1. TYPE 1 \n";
        cout << "   2. TYPE 2\n";
        cout << "   3. TYPE 3\n";
        cout << "   4. TYPE 4\n";
        cout << "   5. TYPE 5\n";
        cout << "   6. TYPE 6\n";
        cout << "   7. TYPE 7\n";
        cout << "   0. QUIT\n";
        cout << "----------------------------------------\n";
        cout << "Select Type: ";

        int type;
        cin >> type;
        cin.ignore(30000, '\n'); // 버퍼안비우면 에러새익;

        if (type == 0)
        {
            break;
        }

        switch (type)
        {
        case 1:
            exeproduct();
            break;
        case 2:
            exetopselling();
            break;
        case 3:
            exestoreperformanc();
            break;
        case 4:
            exevendorstats();
            break;
        case 5:
            exeinventory();
            break;
        case 6:
            exeperchaseing();
            break;
        case 7:
            execomparison();
            break;
        }
    }

    // MySQL 연결 종료
    mysql_close(connection);
    cout << "\nBye!\n";

    return 0;
}

/**
 * @brief
 * @param query
 */
void query_print(const char *query)
{

    if (mysql_query(connection, query))
    {
        cout << "MySQL Query Error: " << mysql_error(connection) << endl;
        return;
    }

    // 왜안되냐이거.. -> 해결함;
    sql_result = mysql_store_result(connection);
    if (sql_result == NULL)
    {
        if (mysql_field_count(connection) == 0)
        {
            cout << "Query OK, " << mysql_affected_rows(connection) << " rows affected." << endl;
        }
        else
        {
            cout << "mysql_store_result() Error: " << mysql_error(connection) << endl;
        }
        return;
    }

    int num_fields = mysql_num_fields(sql_result);
    MYSQL_FIELD *fields = mysql_fetch_fields(sql_result);

    for (int i = 0; i < num_fields; i++)
    {
        cout << "* " << left << setw(15) << fields[i].name;
    }
    cout << "*\n";

    while ((sql_row = mysql_fetch_row(sql_result)) != NULL)
    {
        for (int i = 0; i < num_fields; i++)
        {
            cout << "* " << left << setw(15) << (sql_row[i] ? sql_row[i] : "NULL");
        }
        cout << "*\n";
    }

    mysql_free_result(sql_result);
}

void exeproduct()
{
    cout << "\n--- TYPE 1 ---" << endl;
    cout << "** Which stores currently carry a certain product (by UPC, name, or brand), and how much inventory do they have? ** \n";
    cout << "Enter product identifier (UPC, name, or brand): ";

    string input;
    cin >> input;

    char query[1024];
    sprintf(query, R"(
        SELECT s.store_id, s.store_name, i.current_quantity 
        FROM inventory i JOIN store s ON i.store_id = s.store_id 
        JOIN product p ON i.product_upc = p.product_upc 
        WHERE p.product_upc = '%s' OR p.product_name = '%s' OR p.brand = '%s';
    )",
            input.c_str(), input.c_str(), input.c_str());
    query_print(query);
}

void exetopselling()
{
    cout << "\n--- TYPE 2 ---" << endl;
    cout << "** Which products have the highest sales volume in each store over the past month? ** \n";

    char query[2025];
    // 일단 join 부터 -> join 하고 where 로 거르고 group by 로 묶고 닷 having
    sprintf(query, R"(
    SELECT
        s.store_id,
        p.product_name
    FROM sale_detail d 
        JOIN sale    sa ON sa.sale_id    = d.sale_id
        JOIN product p  ON p.product_upc = d.product_upc
        JOIN store   s  ON s.store_id    = sa.store_id
    WHERE
        YEAR(sa.sale_time)  = YEAR(CURDATE() - INTERVAL 1 MONTH)
        AND MONTH(sa.sale_time) = MONTH(CURDATE() - INTERVAL 1 MONTH)
    GROUP BY
        s.store_id, p.product_name
    HAVING
        SUM(d.quantity) = (
            SELECT MAX(sub_qty)
            FROM (
                SELECT SUM(d2.quantity) AS sub_qty
                FROM sale_detail d2
                JOIN sale sa2 ON sa2.sale_id = d2.sale_id
                WHERE
                    sa2.store_id = s.store_id
                    AND YEAR(sa2.sale_time)  = YEAR(CURDATE() - INTERVAL 1 MONTH)
                    AND MONTH(sa2.sale_time) = MONTH(CURDATE() - INTERVAL 1 MONTH)
                GROUP BY d2.product_upc
            ) AS monthly_max
        );
)");
    query_print(query);
}

void exestoreperformanc()
{
    cout << "\n--- TYPE 3 ---" << endl;
    cout << "** Which store has generated the highest overall revenue this quarter? **\n";

    char query[1024];
    sprintf(query, R"(
        SELECT  s.store_id,
                s.store_name
        FROM    sale  AS sa
        JOIN    store AS s  ON s.store_id = sa.store_id
        WHERE   sa.sale_time >=  MAKEDATE(YEAR(CURDATE()), 1) + INTERVAL (QUARTER(CURDATE())-1)*3 MONTH
        AND   sa.sale_time <   MAKEDATE(YEAR(CURDATE()), 1)  + INTERVAL  QUARTER(CURDATE())   *3 MONTH
        GROUP BY s.store_id, s.store_name
        ORDER BY SUM(sa.total_money) DESC
        LIMIT 1;

    )");
    query_print(query);
}

// type 4 : 가장 많이 공급한거 찾기
void exevendorstats()
{
    cout << "\n--- TYPE 4 ---" << endl;
    cout << "** Which vendor supplies the most products across the chain, and how many total units have been sold? **\n";

    char query[524];
    sprintf(query, R"(
        SELECT
            v.vendor_id,
            v.vendor_name,
            COUNT(p.product_upc) AS num_products,
            SUM(d.quantity)     AS total_sold
        FROM vendor v
        JOIN product p ON p.vendor_id = v.vendor_id
        JOIN sale_detail d ON d.product_upc = p.product_upc
        GROUP BY v.vendor_id, v.vendor_name
        ORDER BY num_products DESC
        LIMIT 1;
    )");

    query_print(query);
}

// 5 : threashold 넘은거 찾기
void exeinventory()
{
    cout << "\n--- TYPE 5 ---" << endl;
    cout << "** Which products in each store are below the reorder threshold and need restocking? **\n";

    char query[1024];
    sprintf(query, R"(
        SELECT
           s.store_id,
           s.store_name,
             p.product_name,
             i.current_quantity,
             i.reorder_thresholds
        FROM
          inventory i JOIN store   s ON i.store_id    = s.store_id
          JOIN product p ON i.product_upc = p.product_upc
        WHERE
            i.current_quantity < i.reorder_thresholds;
    )");

    query_print(query);
}

void exeperchaseing()
{
    cout << "\n--- TYPE 6 ---" << endl;
    cout << "** List the top 3 items that customers typically purchase with coffee. **\n";

    string input;
    cout << "Enter product keyword: ";
    cin >> input;

    char query[1024];
    sprintf(query, R"(
        SELECT
            p2.product_name,
            SUM(d2.quantity) AS total_qty
        FROM sale_detail d1
        JOIN product p1 ON p1.product_upc = d1.product_upc
        JOIN sale_detail d2 ON d2.sale_id = d1.sale_id AND d2.product_upc <> d1.product_upc
        JOIN product p2 ON p2.product_upc = d2.product_upc
        WHERE p1.product_name = '%s'
        GROUP BY p2.product_name
        ORDER BY total_qty DESC
        LIMIT 3;
    )",
            input.c_str());

    query_print(query);
}

void execomparison()
{
    cout << "\n--- TYPE 7 ---" << endl;
    cout << "** Among franchise vs. corporate stores, show the single store in each category with the widest variety of products. **\n";

    char query[1024];

    cout << "\n-- Franchise --\n";
    sprintf(query, R"(
        SELECT
            s.store_id,
            s.store_name,
            COUNT(DISTINCT i.product_upc) AS wide
        FROM store s
        JOIN inventory i ON i.store_id = s.store_id
        WHERE s.owner_type = 'Franchise'
        GROUP BY s.store_id, s.store_name
        ORDER BY wide DESC
        LIMIT 1;
    )");
    query_print(query);

    cout << "\n-- Corporate --\n";
    sprintf(query, R"(
        SELECT
            s.store_id,
            s.store_name,
            COUNT(DISTINCT i.product_upc) AS wide
        FROM store s
        JOIN inventory i
          ON i.store_id = s.store_id
        WHERE s.owner_type = 'Corporate'
        GROUP BY
            s.store_id,
            s.store_name
        ORDER BY
            wide DESC
        LIMIT 1;
    )");
    query_print(query);
}
