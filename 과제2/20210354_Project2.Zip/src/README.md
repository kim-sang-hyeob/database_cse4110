## 대전제

cpp + mysql + mysqlworkbench 를 사용한 프로그램입니다.
7가지 쿼리를 처리 할 수 있도록 cpp 코드를 구성했습니다.

## 기능 개요

| 타입 | 설명                                             |
| ---- | ------------------------------------------------ |
| 1    | 특정 상품(UPC, 이름, 브랜드) 보유 매장/재고 조회 |
| 2    | 지난달 매장별 최다 판매 상품                     |
| 3    | 이번 분기 최고 매출 매장                         |
| 4    | 가장 많이 공급한 벤더 & 총 판매량                |
| 5    | 재주문 임계치 이하시 재고 알림                   |
| 6    | 커피와 함께 구매된 상위 3개 품목                 |
| 7    | 프랜차이즈/기업별 가장 다양한 상품 보유 매장     |

## 데이터 설 명

- 총 매장: 5 (Franchise 3, Corporate 2)
- 상품: 10종 (Vendor 101: 4종 · 102: 3종 · 103/104: 2종)
- 재고: 30행 — 재주문 임계치 미만 7행(Type 5 결과)
- 판매 기록: 2025-Q2 기간 12건(영수증 12, 품목 30)
  - 지난달(2025-05) 매출 포함 → Type 2,3 테스트 확보
- 쿼리 보장: 모든 SELECT Type 1–7 에서 최소 1행 이상 반환

## 폴더 구조

20210354_Project2/
docs/
logical_schema.png
physical_schema.png
project_report.pdf
database/
schema.sql
sample_data.sql
src/
main.cpp (or main.c)
database.h( 없어서 넣지 않음.)
README.md
libmysql.dll (있어야 빌드되는 경우에 넣어야 한다고 하셔서 넣었습니다.)

**포트/계정**  
 const char *host = "127.0.0.1";
const char *user = "root";
const char *pw = "qwer1234";
const char *db = "store";
const unsigned int port = 3306;
비밀번호가 1234 가 아니라 qwer1234 입니다. ( readme.md 에 비밀번호를 적으면 비밀번호를 바꿔도 상관 없다고 하셔서 이렇게 구성했습니다. )

## 설치 & 빌드

| **window** | window 11 ( version 24H2 입니다.)
| **Compiler** | g++.exe (x86_64-posix-seh-rev0, Built by MinGW-Builds project) 15.1.0
| **MySQL Server** | Ver 8.0.42 for Win64 on x86_64 (MySQL Community Server - GPL) |
| **MySQL Connector/C** | 6.1.11.0 |
| **libmysql.dll** | `libmysql.dll` 파일을 Exe 파일 옆에 복사하거나, 해당 폴더를 시스템 `PATH`에 추가 | --> 저는 libmysql.dll 이 exe 파일과 같이 있는 경우에 실행하는것을 환경 기준으로 잡고 과제 진행하였습니다. |
++ 추가 : .vscode 파일에 반드시 아래 설정이 되어있어야 멀쩡히 작동합니다. 다만 이부분은 사람마다 환경이 달라서 확신이 없습니다..

위 환경에서 컴파일하면 (libmysql.dll + .vscode 파일 설정시에 ) 문제 없이 돌아가는 것으로 cross check 했습니다.

## cf. ./vscode 내 파일 내용 명시

3개의 파일이 있어야 잘 구동 되는 것 같습니다.

.vscode
|- launch.json
|- task.json
|- setting.json

task.json파일 :

{
"version": "2.0.0",
"tasks": [
{
"label": "Build MySQL C App",
"type": "shell",
"command": "C:/mingw64/bin/g++.exe",
"args": [
"-fdiagnostics-color=always",
"-g",

        // ─── -I 옵션과 경로를 분리 ───
        "-I",
        "C:/Program Files/MySQL/MySQL Connector C 6.1/include",

        // ─── -L 옵션과 경로를 분리 ───
        "-L",
        "C:/Program Files/MySQL/MySQL Connector C 6.1/lib",

        // ─── 현재 편집 중인 소스 파일 ───
        "${file}",

        // ─── 실제 링커가 찾을 라이브러리 이름 ───
        //  Connector C 6.1 lib 폴더 안에 'libmysql.dll.a'가 있으면 "-lmysql"
        //  만약 'libmysqlclient.a'만 있다면 "-lmysqlclient"로 바꿔주셔야 합니다.
        "-lmysql",

        // ─── 출력 실행 파일 이름 ───
        "-o",
        "${fileDirname}\\${fileBasenameNoExtension}.exe"
      ],
      "options": {
        "cwd": "${workspaceFolder}",
        "shell": {
          "executable": "cmd.exe",
          "args": ["/c"]
        }
      },
      "problemMatcher": ["$gcc"],
      "group": {
        "kind": "build",
        "isDefault": true
      }
    }

]
}

settings.json 파일 내용 :

{
"files.associations": {
"\*.dbclient-js": "javascript",
"string": "cpp",
"ctime": "cpp",
"cstring": "cpp",
"ostream": "cpp",
"iostream": "cpp",
"xstring": "cpp",
"ios": "cpp"
}
}

lauch.json 파일 내용 :
{
// Use IntelliSense to learn about possible attributes.
// Hover to view descriptions of existing attributes.
// For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
"version": "0.2.0",
"configurations": [

    ]

}

## 문제 상황

vscode 에서 shift + b 로 빌드시 (만약에 설정하지 않은 경우) 에러발생

cmd /c chcp 65001>nul && C:\mingw64\bin\g++.exe -fdiagnostics-color=always -g "C:~~~\20210354_Project2\src\main.cpp" -o "C:\~~~~\20210354_Project2\src\main.exe"
C:\Users\mall\OneDrive\바탕 화면\20210354_Project2\src\main.cpp:6:10: fatal error: mysql.h: No such file or directory
6 | #include <mysql.h>
| ^~~~~~~~~
compilation terminated.

Build finished with error(s).

- The terminal process failed to launch (exit code: -1).
- Terminal will be reused by tasks, press any key to close it.

3개 파일 + libmysql.dll 이 있는 경우에 빌드가 잘 되고 실행되는 것을 cross check 했습니다 !!
